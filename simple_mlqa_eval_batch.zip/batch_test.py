#!/usr/bin/env python3
"""
Batch testing script for evaluating multiple embedding models on MLQA retrieval task
"""

import json
import time
import os
import argparse
from typing import List, Dict, Any
from datetime import datetime
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from evaluate import evaluate_model, SimpleMLQARetrieval


class BatchEvaluator:
    """Batch evaluator for multiple embedding models"""

    def __init__(self, models_list: List[str], output_dir: str = "batch_results"):
        self.models_list = models_list
        self.output_dir = output_dir
        self.results = {}
        self.summary_data = []

        # Create output directory
        os.makedirs(output_dir, exist_ok=True)

        # Set matplotlib font for better display
        plt.rcParams['font.sans-serif'] = ['DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False

    def run_evaluation(self, calculate_nauc: bool = False, split: str = "validation"):
        """Run batch evaluation"""
        print(f"Starting batch evaluation for {len(self.models_list)} models...")
        print(f"Models list: {self.models_list}")
        print(f"Output directory: {self.output_dir}")

        for i, model_name in enumerate(self.models_list, 1):
            print(f"\n{'='*60}")
            print(f"Testing model {i}/{len(self.models_list)}: {model_name}")
            print(f"{'='*60}")

            # Create individual output file for each model
            model_output_file = os.path.join(self.output_dir, f"{model_name.replace('/', '_')}_results.json")

            try:
                # Run evaluation
                start_time = time.time()
                result = evaluate_model(
                    model_name=model_name,
                    output_file=model_output_file,
                    calculate_nauc=calculate_nauc
                )
                evaluation_time = time.time() - start_time

                # Store results
                self.results[model_name] = {
                    "result": result,
                    "evaluation_time": evaluation_time,
                    "output_file": model_output_file
                }

                print(f"✅ {model_name} evaluation completed (time: {evaluation_time:.2f}s)")

            except Exception as e:
                print(f"❌ {model_name} evaluation failed: {str(e)}")
                self.results[model_name] = {
                    "error": str(e),
                    "evaluation_time": 0,
                    "output_file": None
                }

        print(f"\n{'='*60}")
        print("Batch evaluation completed!")
        print(f"{'='*60}")

        # Generate comparison results
        self.generate_comparison_report()
        self.generate_visualizations()

    def generate_comparison_report(self):
        """Generate comparison report"""
        print("\nGenerating comparison report...")

        # Prepare comparison data
        comparison_data = []

        for model_name, model_data in self.results.items():
            if "error" in model_data:
                continue

            result = model_data["result"]
            evaluation_time = model_data["evaluation_time"]

            # Extract key metrics for each language pair
            for lang_pair, metrics in result["results"].items():
                comparison_row = {
                    "model": model_name,
                    "language_pair": lang_pair,
                    "evaluation_time": evaluation_time,
                    "num_queries": metrics["num_queries"],
                    "num_corpus_docs": metrics["num_corpus_docs"]
                }

                # Add key metrics
                for k in [1, 3, 5, 10, 20, 50]:
                    comparison_row[f"ndcg_at_{k}"] = metrics.get(f"ndcg_at_{k}", 0.0)
                    comparison_row[f"map_at_{k}"] = metrics.get(f"map_at_{k}", 0.0)
                    comparison_row[f"recall_at_{k}"] = metrics.get(f"recall_at_{k}", 0.0)
                    comparison_row[f"precision_at_{k}"] = metrics.get(f"precision_at_{k}", 0.0)

                # Add nAUC metrics (if available)
                nauc_keys = [k for k in metrics.keys() if k.startswith("nauc_")]
                for key in nauc_keys:
                    comparison_row[key] = metrics[key]

                comparison_data.append(comparison_row)

        # Create DataFrame
        self.comparison_df = pd.DataFrame(comparison_data)

        # Save comparison data
        comparison_file = os.path.join(self.output_dir, "comparison_results.csv")
        self.comparison_df.to_csv(comparison_file, index=False)
        print(f"Comparison data saved to: {comparison_file}")

        # Generate detailed comparison report
        self.generate_detailed_report()

    def generate_detailed_report(self):
        """Generate detailed comparison report"""
        report_lines = []
        report_lines.append("# MLQA Batch Evaluation Comparison Report")
        report_lines.append(f"Generated at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report_lines.append(f"Number of models tested: {len(self.models_list)}")
        report_lines.append("")

        # Model performance overview
        report_lines.append("## Model Performance Overview")
        report_lines.append("")

        # Sort by NDCG@10
        if not self.comparison_df.empty:
            # Get average performance across all language pairs
            avg_performance = self.comparison_df.groupby('model').agg({
                'ndcg_at_10': 'mean',
                'map_at_10': 'mean',
                'recall_at_10': 'mean',
                'evaluation_time': 'mean'
            }).sort_values('ndcg_at_10', ascending=False)

            report_lines.append("| Rank | Model | NDCG@10 | MAP@10 | Recall@10 | Eval Time (s) |")
            report_lines.append("|------|-------|---------|--------|-----------|---------------|")

            for i, (model, row) in enumerate(avg_performance.iterrows(), 1):
                report_lines.append(f"| {i} | {model} | {row['ndcg_at_10']:.4f} | {row['map_at_10']:.4f} | {row['recall_at_10']:.4f} | {row['evaluation_time']:.2f} |")

            report_lines.append("")

            # Detailed comparison by language pair
            report_lines.append("## Detailed Comparison by Language Pair")
            report_lines.append("")

            for lang_pair in self.comparison_df['language_pair'].unique():
                report_lines.append(f"### {lang_pair}")
                report_lines.append("")

                lang_data = self.comparison_df[self.comparison_df['language_pair'] == lang_pair]
                lang_sorted = lang_data.sort_values('ndcg_at_10', ascending=False)

                report_lines.append("| Model | NDCG@1 | NDCG@3 | NDCG@5 | NDCG@10 | NDCG@20 | NDCG@50 | MAP@10 | Recall@10 |")
                report_lines.append("|-------|--------|--------|--------|----------|----------|----------|--------|-----------|")

                for _, row in lang_sorted.iterrows():
                    report_lines.append(f"| {row['model']} | {row['ndcg_at_1']:.4f} | {row['ndcg_at_3']:.4f} | {row['ndcg_at_5']:.4f} | {row['ndcg_at_10']:.4f} | {row['ndcg_at_20']:.4f} | {row['ndcg_at_50']:.4f} | {row['map_at_10']:.4f} | {row['recall_at_10']:.4f} |")

                report_lines.append("")

        # Save report
        report_file = os.path.join(self.output_dir, "comparison_report.md")
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write('\n'.join(report_lines))

        print(f"Detailed comparison report saved to: {report_file}")

    def generate_visualizations(self):
        """Generate visualization charts"""
        print("\nGenerating visualization charts...")

        if self.comparison_df.empty:
            print("No valid data available, skipping visualization")
            return

        # 1. Model performance comparison chart (NDCG@10)
        plt.figure(figsize=(12, 8))

        # Group by language pair
        fig, axes = plt.subplots(1, 2, figsize=(16, 6))

        # Left chart: NDCG@10 comparison
        ndcg_data = self.comparison_df.pivot_table(
            index='model',
            columns='language_pair',
            values='ndcg_at_10'
        )

        if not ndcg_data.empty:
            ndcg_data.plot(kind='bar', ax=axes[0])
            axes[0].set_title('NDCG@10 Performance Comparison')
            axes[0].set_ylabel('NDCG@10 Score')
            axes[0].set_xlabel('Model')
            axes[0].legend(title='Language Pair')
            axes[0].tick_params(axis='x', rotation=45)

        # Right chart: Evaluation time comparison
        time_data = self.comparison_df.groupby('model')['evaluation_time'].mean()
        if not time_data.empty:
            time_data.plot(kind='bar', ax=axes[1])
            axes[1].set_title('Evaluation Time Comparison')
            axes[1].set_ylabel('Time (seconds)')
            axes[1].set_xlabel('Model')
            axes[1].tick_params(axis='x', rotation=45)

        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, 'performance_comparison.png'), dpi=300, bbox_inches='tight')
        plt.close()

        # 2. Multi-metric radar chart
        self.generate_radar_chart()

        # 3. Detailed metrics comparison chart
        self.generate_detailed_metrics_chart()

        print(f"Visualization charts saved to: {self.output_dir}")

    def generate_radar_chart(self):
        """Generate radar chart"""
        if self.comparison_df.empty:
            return

        # Select top 5 models for radar chart comparison
        top_models = self.comparison_df.groupby('model')['ndcg_at_10'].mean().nlargest(5).index.tolist()

        if len(top_models) < 2:
            return

        # Select key metrics
        metrics = ['ndcg_at_1', 'ndcg_at_3', 'ndcg_at_5', 'ndcg_at_10', 'ndcg_at_20', 'ndcg_at_50']

        # Calculate average values for each metric
        radar_data = []
        for model in top_models:
            model_data = self.comparison_df[self.comparison_df['model'] == model]
            avg_scores = [model_data[metric].mean() for metric in metrics]
            radar_data.append(avg_scores)

        # Create radar chart
        angles = np.linspace(0, 2 * np.pi, len(metrics), endpoint=False).tolist()
        angles += angles[:1]  # Close the shape

        fig, ax = plt.subplots(figsize=(10, 10), subplot_kw=dict(projection='polar'))

        colors = plt.cm.Set3(np.linspace(0, 1, len(top_models)))

        for i, (model, scores) in enumerate(zip(top_models, radar_data)):
            scores += scores[:1]  # Close the shape
            ax.plot(angles, scores, 'o-', linewidth=2, label=model, color=colors[i])
            ax.fill(angles, scores, alpha=0.25, color=colors[i])

        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(metrics)
        ax.set_ylim(0, 1)
        ax.set_title('Top Models Performance Radar Chart', size=16, weight='bold', pad=20)
        ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.0))

        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, 'radar_chart.png'), dpi=300, bbox_inches='tight')
        plt.close()

    def generate_detailed_metrics_chart(self):
        """Generate detailed metrics comparison chart"""
        if self.comparison_df.empty:
            return

        # Create multi-subplot to show different metrics
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))

        # Get top 5 models by average performance
        top_models = self.comparison_df.groupby('model')['ndcg_at_10'].mean().nlargest(5).index.tolist()

        # Filter data
        plot_data = self.comparison_df[self.comparison_df['model'].isin(top_models)]

        # NDCG different K values comparison
        ndcg_cols = [f'ndcg_at_{k}' for k in [1, 3, 5, 10, 20, 50]]
        ndcg_melted = plot_data.melt(id_vars=['model', 'language_pair'], value_vars=ndcg_cols,
                                   var_name='K', value_name='Score')

        sns.barplot(data=ndcg_melted, x='K', y='Score', hue='model', ax=axes[0, 0])
        axes[0, 0].set_title('NDCG@K Comparison')
        axes[0, 0].set_ylabel('NDCG Score')
        axes[0, 0].legend(bbox_to_anchor=(1.05, 1), loc='upper left')

        # MAP comparison
        map_cols = [f'map_at_{k}' for k in [1, 3, 5, 10]]
        map_melted = plot_data.melt(id_vars=['model', 'language_pair'], value_vars=map_cols,
                                  var_name='K', value_name='Score')

        sns.barplot(data=map_melted, x='K', y='Score', hue='model', ax=axes[0, 1])
        axes[0, 1].set_title('MAP@K Comparison')
        axes[0, 1].set_ylabel('MAP Score')
        axes[0, 1].legend(bbox_to_anchor=(1.05, 1), loc='upper left')

        # Recall comparison
        recall_cols = [f'recall_at_{k}' for k in [1, 3, 5, 10, 20, 50]]
        recall_melted = plot_data.melt(id_vars=['model', 'language_pair'], value_vars=recall_cols,
                                      var_name='K', value_name='Score')

        sns.barplot(data=recall_melted, x='K', y='Score', hue='model', ax=axes[1, 0])
        axes[1, 0].set_title('Recall@K Comparison')
        axes[1, 0].set_ylabel('Recall Score')
        axes[1, 0].legend(bbox_to_anchor=(1.05, 1), loc='upper left')

        # Precision comparison
        precision_cols = [f'precision_at_{k}' for k in [1, 3, 5, 10, 20, 50]]
        precision_melted = plot_data.melt(id_vars=['model', 'language_pair'], value_vars=precision_cols,
                                         var_name='K', value_name='Score')

        sns.barplot(data=precision_melted, x='K', y='Score', hue='model', ax=axes[1, 1])
        axes[1, 1].set_title('Precision@K Comparison')
        axes[1, 1].set_ylabel('Precision Score')
        axes[1, 1].legend(bbox_to_anchor=(1.05, 1), loc='upper left')

        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, 'detailed_metrics.png'), dpi=300, bbox_inches='tight')
        plt.close()


def load_models_from_config(config_file: str) -> List[str]:
    """Load models list from configuration file"""
    if os.path.exists(config_file):
        with open(config_file, 'r', encoding='utf-8') as f:
            config = json.load(f)
            return config.get('models', [])
    return []


def main():
    parser = argparse.ArgumentParser(description="Batch evaluate multiple embedding models")
    parser.add_argument("--models", nargs='+',
                       default=[
                           "all-MiniLM-L6-v2",
                           "intfloat/multilingual-e5-small",
                           "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
                       ],
                       help="List of models to test")
    parser.add_argument("--config", type=str,
                       help="Load models list from configuration file (JSON format)")
    parser.add_argument("--output-dir", type=str, default="batch_results",
                       help="Output directory")
    parser.add_argument("--calculate_nauc", action="store_true",
                       help="Calculate nAUC metrics")
    parser.add_argument("--split", type=str, default="validation",
                       choices=["validation", "test"],
                       help="Dataset split to use")

    args = parser.parse_args()

    # Load models list from configuration file (if specified)
    if args.config:
        models = load_models_from_config(args.config)
        if models:
            print(f"Loading models list from configuration file: {models}")
            args.models = models

    print(f"Testing the following models: {args.models}")

    # Create batch evaluator
    evaluator = BatchEvaluator(
        models_list=args.models,
        output_dir=args.output_dir
    )

    # Run evaluation
    evaluator.run_evaluation(
        calculate_nauc=args.calculate_nauc,
        split=args.split
    )

    print(f"\n✅ Batch evaluation completed! Results saved in: {args.output_dir}")


if __name__ == "__main__":
    main()