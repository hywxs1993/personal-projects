# Batch Evaluation Script

This script provides comprehensive batch evaluation capabilities for multiple embedding models on the MLQA retrieval task.

## Features

- **Batch Testing**: Evaluate multiple models in sequence
- **Configurable Models**: Support for model lists via command line or JSON configuration
- **Comprehensive Analysis**: Detailed comparison reports and visualizations
- **Multiple Metrics**: NDCG@K, MAP@K, Recall@K, Precision@K for K=[1,3,5,10,20,50]
- **Optional nAUC**: Advanced confidence-based metrics
- **Rich Visualizations**: Performance charts, radar plots, and detailed metrics comparison
- **Flexible Output**: CSV data, Markdown reports, and PNG charts

## Usage

### Basic Usage

```bash
# Test default models
python batch_test.py

# Test specific models
python batch_test.py --models all-MiniLM-L6-v2 intfloat/multilingual-e5-small

# Test with nAUC metrics
python batch_test.py --calculate_nauc

# Use test split instead of validation
python batch_test.py --split test
```

### Configuration File Usage

```bash
# Use models from configuration file
python batch_test.py --config models_config.json
```

### Advanced Usage

```bash
# Custom output directory
python batch_test.py --output-dir my_results

# Test with nAUC on test split
python batch_test.py --calculate_nauc --split test --output-dir detailed_results
```

## Configuration File Format

Create a JSON configuration file (`models_config.json`):

```json
{
  "models": [
    "all-MiniLM-L6-v2",
    "intfloat/multilingual-e5-small",
    "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
  ],
  "description": "My model list",
  "created_at": "2025-01-15"
}
```

## Output Files

The script generates several output files in the specified directory:

### Data Files
- `comparison_results.csv`: Raw comparison data in CSV format
- `comparison_report.md`: Detailed Markdown report
- `{model_name}_results.json`: Individual model results

### Visualization Files
- `performance_comparison.png`: Performance and time comparison charts
- `radar_chart.png`: Radar chart for top performing models
- `detailed_metrics.png`: Detailed metrics comparison across all K values

## Sample Models

The default configuration includes:
- `all-MiniLM-L6-v2`: Lightweight general-purpose model
- `intfloat/multilingual-e5-small`: Small multilingual E5 model
- `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2`: Multilingual paraphrase model

## Command Line Options

```
--models           List of models to test (space-separated)
--config           JSON configuration file with models list
--output-dir       Output directory for results (default: batch_results)
--calculate_nauc   Calculate nAUC metrics (computationally expensive)
--split            Dataset split to use: validation or test (default: validation)
--help             Show help message
```

## Examples

### Quick Test
```bash
python batch_test.py
```

### Comprehensive Analysis
```bash
python batch_test.py --config models_config.json --calculate_nauc --split test --output-dir comprehensive_results
```

### Custom Model List
```bash
python batch_test.py --models "model1" "model2" "model3" --output-dir custom_test
```

## Requirements

The script requires additional dependencies:
```
pandas>=1.3.0
matplotlib>=3.5.0
seaborn>=0.11.0
numpy>=1.21.0
```

Install with:
```bash
pip install pandas matplotlib seaborn numpy
```