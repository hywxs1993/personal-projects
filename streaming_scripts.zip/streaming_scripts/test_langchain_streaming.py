"""
LangChain Streaming Examples with Azure OpenAI
Demonstrates different streaming approaches using LangChain framework
"""

from langchain_openai import AzureChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser


# Configuration

API_VERSION = "2025-01-01-preview"
DEPLOYMENT_NAME = "gpt-4o"


def example_1_basic_streaming():
    """
    Example 1: Basic streaming with .stream() method
    Simplest way to stream responses in LangChain
    """
    print("\n" + "=" * 80)
    print("Example 1: Basic Streaming with .stream()")
    print("=" * 80 + "\n")

    # Initialize Azure OpenAI chat model
    llm = AzureChatOpenAI(
        azure_endpoint=AZURE_ENDPOINT,
        api_key=API_KEY,
        api_version=API_VERSION,
        deployment_name=DEPLOYMENT_NAME,
        temperature=0.7,
    )

    # Simple message
    messages = [
        ("system", "You are a helpful assistant."),
        ("human", "Write a haiku about programming")
    ]

    print("Assistant (streaming): ")

    # Stream response
    for chunk in llm.stream(messages):
        print(chunk.content, end="", flush=True)

    print("\n")


def example_2_chain_streaming():
    """
    Example 2: Streaming with LangChain chains (LCEL)
    Using LangChain Expression Language with streaming
    """
    print("\n" + "=" * 80)
    print("Example 2: Chain Streaming with LCEL")
    print("=" * 80 + "\n")

    # Initialize LLM
    llm = AzureChatOpenAI(
        azure_endpoint=AZURE_ENDPOINT,
        api_key=API_KEY,
        api_version=API_VERSION,
        deployment_name=DEPLOYMENT_NAME,
        temperature=0.7,
    )

    # Create prompt template
    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", "You are a helpful assistant."),
            ("human", "Tell me a joke about {topic}")
        ]
    )

    # Create chain with output parser
    chain = prompt | llm | StrOutputParser()

    # Stream the chain
    print("Assistant (chain streaming): ")

    for chunk in chain.stream({"topic": "programming"}):
        print(chunk, end="", flush=True)

    print("\n")


if __name__ == "__main__":
    print("""
╔══════════════════════════════════════════════════════════════════════╗
║        LangChain Streaming Examples for Azure OpenAI                    ║
╚══════════════════════════════════════════════════════════════════════╝
    """)

    try:
        # Run examples
        example_1_basic_streaming()
        example_2_chain_streaming()

        print("\n" + "=" * 80)
        print("All examples completed successfully!")
        print("=" * 80 + "\n")

    except Exception as e:
        print(f"\n❌ Error occurred: {e}")
        print("\nTroubleshooting tips:")
        print("1. Ensure langchain-openai is installed: pip install langchain-openai")
        print("2. Check if your API key is correct")
        print("3. Verify the deployment name matches your Azure OpenAI deployment")
        print("4. Ensure the endpoint URL is correct")
        print("5. Check your network connection")