# OpenAI SDK Streaming Implementation Guide

This document provides a comprehensive overview of how the OpenAI Python SDK handles streaming output, including internal mechanisms, data structures, and best practices.

## Table of Contents

- [Overview](#overview)
- [Streaming Approaches](#streaming-approaches)
- [Data Structures](#data-structures)
- [Event System](#event-system)
- [Internal Implementation](#internal-implementation)
- [Comparison](#comparison)
- [Best Practices](#best-practices)

---

## Overview

The OpenAI Python SDK provides two primary methods for handling streaming responses from chat completion APIs:

1. **`.create(stream=True)`** - Basic streaming with raw chunks
2. **`.stream()`** - Advanced streaming with event-based architecture

Both methods use Server-Sent Events (SSE) protocol under the hood to deliver incremental content as it's generated.

---

## Streaming Approaches

### Method 1: Basic Streaming with `.create(stream=True)`

The simplest way to enable streaming is by setting `stream=True` in the `create()` method.

```python
from openai import OpenAI

client = OpenAI()

stream = client.chat.completions.create(
    model="gpt-4",
    messages=[
        {"role": "user", "content": "How do I output all files in a directory using Python?"}
    ],
    stream=True,  # Enable streaming
)

# Iterate over chunks
for chunk in stream:
    if not chunk.choices:
        continue
    # Print each chunk as it arrives
    print(chunk.choices[0].delta.content, end="")

print()
```

**Characteristics:**
- ✅ Simple and straightforward
- ✅ Returns `ChatCompletionChunk` objects
- ❌ Requires manual checking for `chunk.choices`
- ❌ Requires manual extraction of `delta.content`
- ❌ No automatic accumulation of content

### Method 2: Advanced Streaming with `.stream()`

The `.stream()` method provides a more sophisticated event-based API with automatic content accumulation.

```python
from openai import OpenAI

client = OpenAI()

# Context manager is required
with client.chat.completions.stream(
    model='gpt-4o-2024-08-06',
    messages=[{"role": "user", "content": "Write a short story"}],
) as stream:
    for event in stream:
        if event.type == 'content.delta':
            print(event.content, end='')
```

**Characteristics:**
- ✅ Granular event API
- ✅ Automatic content accumulation
- ✅ Type-safe event system
- ✅ Context manager ensures proper resource cleanup
- ⚠️ Requires usage within a context manager

---

## Data Structures

### ChatCompletionChunk Structure

When streaming is enabled, each iteration returns a `ChatCompletionChunk` object:

```python
ChatCompletionChunk:
  id: str                          # Unique response identifier
  object: str = "chat.completion.chunk"
  created: int                     # Unix timestamp
  model: str                       # Model name (e.g., "gpt-4")
  choices: List[Choice]            # List of choices

  Choice:
    index: int                     # Choice index
    delta: Delta                   # Incremental content
    finish_reason: Optional[str]   # Completion reason (stop/length)
    logprobs: Optional[Logprobs]   # Log probabilities

  Delta:
    content: Optional[str]         # ⭐ New text fragment
    role: Optional[str]            # Message role
    tool_calls: Optional[List]     # Tool calls array
```

### Example Chunk

```json
{
  "id": "chatcmpl-123",
  "object": "chat.completion.chunk",
  "created": 1234567890,
  "model": "gpt-4",
  "choices": [{
    "index": 0,
    "delta": {
      "content": "Hello"
    },
    "finish_reason": null
  }]
}
```

---

## Event System

The `.stream()` method provides a rich event system with multiple event types:

### Content Events

Track text generation progress:

```python
ContentDeltaEvent:
  type: "content.delta"
  delta: str               # New content fragment
  snapshot: str            # Accumulated content so far
  parsed: Optional[object] # Partially parsed content (if applicable)

ContentDoneEvent:
  type: "content.done"
  content: str             # Full generated content
  parsed: object           # Fully parsed content
```

**Example:**

```python
with client.chat.completions.stream(...) as stream:
    for event in stream:
        if event.type == 'content.delta':
            # Real-time content fragment
            print(event.delta, end='')
        elif event.type == 'content.done':
            # Complete content
            print(f"\nComplete: {event.content}")
```

### Refusal Events

Handle content moderation refusals:

```python
RefusalDeltaEvent:
  type: "refusal.delta"
  delta: str               # New refusal content
  snapshot: str            # Accumulated refusal

RefusalDoneEvent:
  type: "refusal.done"
  refusal: str             # Full refusal content
```

### Tool Call Events

Manage function calling during streaming:

```python
FunctionToolCallArgumentsDeltaEvent:
  type: "tool_calls.function.arguments.delta"
  name: str                # Function name
  index: int               # Tool call index
  arguments: str           # Accumulated JSON string
  parsed_arguments: dict   # Partially parsed arguments
  arguments_delta: str     # New JSON fragment

FunctionToolCallArgumentsDoneEvent:
  type: "tool_calls.function.arguments.done"
  name: str
  index: int
  arguments: str           # Complete JSON string
  parsed_arguments: dict   # Fully parsed arguments
```

**Example:**

```python
with client.chat.completions.stream(...) as stream:
    for event in stream:
        if event.type == 'tool_calls.function.arguments.delta':
            # Handle incremental function arguments
            process_function_args(event.parsed_arguments)
```

### Logprobs Events

Access token probability information:

```python
LogprobsContentDeltaEvent:
  type: "logprobs.content.delta"
  content: List[TokenLogprob]  # New token probabilities
  snapshot: List               # Accumulated probabilities

LogprobsContentDoneEvent:
  type: "logprobs.content.done"
  content: List[TokenLogprob]  # Complete probabilities
```

---

## Internal Implementation

### SSE Parsing

The SDK internally parses Server-Sent Events to transform the HTTP stream into Python objects.

**SSE Format:**
```
data: {"id":"chatcmpl-xxx","choices":[{"delta":{"content":"Hello"}}]}
data: {"id":"chatcmpl-xxx","choices":[{"delta":{"content":" world"}}]}
data: [DONE]
```

**Internal Parsing Logic:**

```python
class ChatCompletionStream:
    def __iter__(self):
        for line in self.response.iter_lines():
            if not line.strip():
                continue

            # Check for SSE data prefix
            if line.startswith(b'data: '):
                data = line[6:]  # Remove "data: " prefix

                # Check for stream termination
                if data == b'[DONE]':
                    break

                # Parse JSON into ChatCompletionChunk
                chunk = ChatCompletionChunk.model_validate_json(data)
                yield chunk
```

### Event Accumulation

The `.stream()` method automatically accumulates delta content:

```python
class ChatCompletionStream:
    def __iter__(self):
        accumulated_content = ""

        for raw_chunk in self._parse_sse():
            # Accumulate content deltas
            if raw_chunk.choices and raw_chunk.choices[0].delta.content:
                new_content = raw_chunk.choices[0].delta.content
                accumulated_content += new_content

                # Yield delta event
                yield ContentDeltaEvent(
                    type="content.delta",
                    delta=new_content,
                    snapshot=accumulated_content
                )

        # Yield completion event
        yield ContentDoneEvent(
            type="content.done",
            content=accumulated_content
        )
```

### HTTP Connection Management

**Without Context Manager:**
```python
stream = client.chat.completions.create(..., stream=True)
# Connection remains open until fully consumed
for chunk in stream:
    print(chunk)
# Connection closed after iteration completes
```

**With Context Manager (`.stream()`):**
```python
with client.chat.completions.stream(...) as stream:
    for event in stream:
        print(event)
# Connection guaranteed to close on exit
```

The context manager ensures proper resource cleanup even if errors occur during iteration.

---

## Comparison

| Feature | `.create(stream=True)` | `.stream()` |
|---------|------------------------|-------------|
| **Return Type** | `Iterator[ChatCompletionChunk]` | `Iterator[Event]` |
| **Context Manager** | ❌ Optional | ✅ Required |
| **Event Types** | ❌ Raw chunks only | ✅ Multiple event types |
| **Auto Accumulation** | ❌ Manual | ✅ Automatic |
| **Type Safety** | ⚠️ Manual checks required | ✅ Event type discrimination |
| **Resource Management** | ⚠️ Manual cleanup | ✅ Automatic cleanup |
| **Use Case** | Simple text streaming | Complex scenarios (tools, logprobs) |
| **Learning Curve** | Simple | Moderate |

---

## Best Practices

### For Simple Text Streaming

When you only need to display text in real-time:

```python
stream = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Tell me a joke"}],
    stream=True
)

for chunk in stream:
    if chunk.choices:
        content = chunk.choices[0].delta.content
        if content:
            print(content, end="", flush=True)
```

### For Complex Streaming

When handling tool calls, logprobs, or refusals:

```python
with client.chat.completions.stream(
    model="gpt-4o",
    messages=[...],
    tools=[function_tool_schema]
) as stream:
    for event in stream:
        if event.type == 'content.delta':
            print(event.content, end='')
        elif event.type == 'tool_calls.function.arguments.delta':
            handle_function(event.name, event.parsed_arguments)
        elif event.type == 'refusal.delta':
            log_refusal(event.delta)
```

### Error Handling

Always handle network errors and parsing issues:

```python
try:
    with client.chat.completions.stream(...) as stream:
        for event in stream:
            # Process events
            pass
except openai.APIError as e:
    print(f"API Error: {e}")
except openai.APIConnectionError as e:
    print(f"Connection Error: {e}")
except Exception as e:
    print(f"Unexpected Error: {e}")
```

### Resource Cleanup

Always consume streams completely or use context managers:

```python
# Good: Context manager ensures cleanup
with client.chat.completions.stream(...) as stream:
    for event in stream:
        if event.type == 'content.delta':
            print(event.content, end='')

# Acceptable: Explicit iteration
stream = client.chat.completions.create(..., stream=True)
for chunk in stream:
    print(chunk.choices[0].delta.content, end='')
# Connection closes after loop

# Bad: Stream not consumed
stream = client.chat.completions.create(..., stream=True)
# Connection leaks if not iterated
```

### Async Streaming

For async/await patterns:

```python
from openai import AsyncOpenAI

client = AsyncOpenAI()

async with client.chat.completions.stream(
    model='gpt-4o',
    messages=[...],
) as stream:
    async for event in stream:
        if event.type == 'content.delta':
            print(event.content, end='')
```

---

## Summary

The OpenAI Python SDK provides flexible streaming capabilities through two complementary approaches:

1. **`.create(stream=True)`** - Best for simple use cases requiring only text streaming
2. **`.stream()`** - Ideal for complex scenarios requiring event-driven architecture, automatic content accumulation, and proper resource management

Understanding the internal SSE parsing mechanism and event system enables developers to choose the right approach for their use case and implement robust streaming solutions.

---

## References

- [OpenAI Python SDK Documentation](https://github.com/openai/openai-python)
- [OpenAI API Reference - Chat Completions](https://platform.openai.com/docs/api-reference/chat/create)
- [Server-Sent Events (SSE) Specification](https://html.spec.whatwg.org/multipage/server-sent-events.html)