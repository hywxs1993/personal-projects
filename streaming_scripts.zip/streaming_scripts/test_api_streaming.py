"""
Azure OpenAI Chat Completion API - Streaming Example
Implement streaming responses using requests library
"""

import requests
import json


def azure_openai_streaming_raw_json():
    """
    Display complete raw JSON content for each chunk
    For in-depth understanding of streaming response data structure
    """

    # Configuration

    DEPLOYMENT_NAME = "gpt-4o"
    API_VERSION = "2025-01-01-preview"

    url = f"{AZURE_OPENAI_ENDPOINT}/openai/deployments/{DEPLOYMENT_NAME}/chat/completions?api-version={API_VERSION}"

    headers = {
        "Content-Type": "application/json",
        "api-key": API_KEY
    }

    payload = {
        "messages": [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Say 'Hello!'"}
        ],
        "max_tokens": 50,
        "temperature": 0.7,
        "stream": True
    }

    try:
        print("\n" + "=" * 80)
        print("Raw JSON Streaming Mode (show complete chunk structure)")
        print("=" * 80 + "\n")

        response = requests.post(url, headers=headers, json=payload, stream=True)

        if response.status_code == 200:
            chunk_num = 0

            for line in response.iter_lines():
                if line:
                    # Show raw line (bytes to string)
                    raw_line = line.decode('utf-8')

                    # Skip empty lines (empty lines separate SSE message blocks)
                    if not raw_line.strip():
                        print(f"\n{'═' * 80}")
                        print(f"[Empty line - SSE message block separator]")
                        print(f"{'═' * 80}")
                        continue

                    # Show raw line content
                    print(f"\n{'─' * 80}")
                    print(f"Raw Line:")
                    print(f"  {repr(raw_line)}")

                    # Parse SSE field format: field_name: field_value
                    if ':' in raw_line:
                        field_name, field_value = raw_line.split(':', 1)
                        field_name = field_name.strip()
                        field_value = field_value.strip()

                        print(f"\nParsed SSE Field:")
                        print(f"  Field Name: {repr(field_name)}")
                        print(f"  Field Value: {repr(field_value)}")

                        # Handle different field types
                        if field_name == 'data':
                            if field_value == '[DONE]':
                                chunk_num += 1
                                print(f"\n✓ [Special Marker] Stream Ended")
                                break

                            try:
                                # Try to parse as JSON
                                chunk = json.loads(field_value)
                                chunk_num += 1

                                print(f"\n✓ [DATA Field] JSON Parsed Successfully (Chunk #{chunk_num}):")
                                print(json.dumps(chunk, indent=2, ensure_ascii=False))

                            except json.JSONDecodeError as e:
                                print(f"\n✗ [DATA Field] JSON Parse Failed: {e}")
                                print(f"  Raw Content: {field_value}")

                        elif field_name == 'event':
                            print(f"\n✓ [EVENT Field] Event Type: {field_value}")

                        elif field_name == 'id':
                            print(f"\n✓ [ID Field] Event ID: {field_value}")

                        elif field_name == 'retry':
                            print(f"\n✓ [RETRY Field] Retry Interval: {field_value}ms")

                        elif field_name.startswith(':'):
                            print(f"\n✓ [Comment Field] SSE Comment: {field_value[1:]}")

                        else:
                            print(f"\n⚠ [Unknown Field Type] {field_name}: {field_value}")

                    else:
                        print(f"\n⚠ Unparseable Line Format (does not contain ':' separator)")

            print(f"\n{'=' * 80}")
            print(f"Total received {chunk_num} chunks")
            print(f"{'=' * 80}\n")

        else:
            print(f"Request failed: {response.status_code} - {response.text}")

    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    print("Azure OpenAI Chat Completion Streaming Example\n")
    azure_openai_streaming_raw_json()