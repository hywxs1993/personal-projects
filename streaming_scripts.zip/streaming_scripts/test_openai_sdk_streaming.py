"""
OpenAI SDK Streaming Example for Azure OpenAI
Demonstrates basic streaming using OpenAI SDK with Azure OpenAI
"""

from openai import AzureOpenAI


# Configuration

API_VERSION = "2025-01-01-preview"
DEPLOYMENT_NAME = "gpt-4o"


def basic_streaming_example():
    """
    Basic streaming with .create(stream=True)
    """
    print("\n" + "=" * 80)
    print("Basic Streaming Example")
    print("=" * 80 + "\n")

    client = AzureOpenAI(
        api_key=API_KEY,
        azure_endpoint=AZURE_ENDPOINT,
        api_version=API_VERSION
    )

    print("Sending request...")

    stream = client.chat.completions.create(
        model=DEPLOYMENT_NAME,
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Write a haiku about programming"}
        ],
        stream=True,
        max_tokens=100
    )

    print("Assistant (streaming): ")
    chunk_index = 0

    for chunk in stream:
        if chunk.choices and chunk.choices[0].delta.content:
            content = chunk.choices[0].delta.content
            print(f"[{chunk_index}] {content}", flush=True)
            chunk_index += 1

    print("\n")


if __name__ == "__main__":
    print("""
╔══════════════════════════════════════════════════════════════════════╗
║          OpenAI SDK Streaming Example for Azure OpenAI                ║
╚══════════════════════════════════════════════════════════════════════╝
    """)

    try:
        basic_streaming_example()
        print("\n" + "=" * 80)
        print("Example completed successfully!")
        print("=" * 80 + "\n")

    except Exception as e:
        print(f"\n❌ Error occurred: {e}")
        print("\nTroubleshooting tips:")
        print("1. Check if your API key is correct")
        print("2. Verify the deployment name matches your Azure OpenAI deployment")
        print("3. Ensure the endpoint URL is correct")
        print("4. Check your network connection")