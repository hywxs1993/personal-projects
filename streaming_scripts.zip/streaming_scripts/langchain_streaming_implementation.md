# LangChain Streaming Implementation Guide

This document provides a comprehensive overview of how LangChain implements streaming output through the `llm.stream()` method, including internal mechanisms, the Runnable interface, and best practices.

## Table of Contents

- [Overview](#overview)
- [The Runnable Interface](#the-runnable-interface)
- [How stream() Works Internally](#how-stream-works-internally)
- [Message Chunks and Accumulation](#message-chunks-and-accumulation)
- [Auto-Streaming](#auto-streaming)
- [Callback System Integration](#callback-system-integration)
- [LCEL Chain Streaming](#lcel-chain-streaming)
- [Custom Streaming with Transform](#custom-streaming-with-transform)

---

## Overview

LangChain provides a unified streaming interface through the `Runnable` protocol. All LangChain components (LLMs, prompts, parsers, tools) implement this interface, enabling consistent streaming behavior across the entire framework.

**Key Features:**
- **Unified Interface**: All components support `stream()`, `invoke()`, `batch()`, and `astream()`
- **Automatic Propagation**: Streaming automatically propagates through chains
- **Chunk Accumulation**: Messages are designed to be aggregated via summation
- **Event System**: Rich callback system for monitoring streaming events

---

## The Runnable Interface

The `Runnable` interface is the foundational protocol that all LangChain components implement. It provides standardized methods for execution:

### Core Methods

```python
from langchain_core.runnables import Runnable

class Runnable:
    def invoke(self, input, config=None):
        """Process a single input and return output"""
        pass

    def stream(self, input, config=None):
        """Stream output chunks as they are generated"""
        pass

    def batch(self, inputs, config=None):
        """Process multiple inputs in parallel"""
        pass

    async def astream(self, input, config=None):
        """Async version of stream()"""
        pass
```

### Default Implementation

The default `stream()` implementation calls `invoke()` and yields the result as a single chunk:

```python
def stream(self, input, config=None):
    """Default implementation - yields complete output"""
    yield self.invoke(input, config)
```

However, LLMs and chat models override this to provide true streaming by yielding individual chunks as they arrive from the underlying API.

---

## How stream() Works Internally

### 1. LLM/Chat Model Streaming

When you call `llm.stream()` on a language model, the following sequence occurs:

```python
# Internal pseudo-code for llm.stream()
def stream(self, input, config=None):
    # 1. Prepare the request
    messages = self._convert_input(input)

    # 2. Call underlying provider API with streaming=True
    api_stream = self._client.generate(messages, stream=True)

    # 3. Iterate over API response chunks
    for api_chunk in api_stream:
        # 4. Convert provider-specific chunk to AIMessageChunk
        langchain_chunk = AIMessageChunk(
            content=api_chunk.text,
            response_metadata=api_chunk.metadata
        )

        # 5. Trigger callback events
        self._trigger_callbacks(
            event="on_llm_new_token",
            token=api_chunk.text,
            chunk=langchain_chunk,
            config=config
        )

        # 6. Yield the chunk to the user
        yield langchain_chunk
```

### 2. Provider-Specific Adapters

Each model provider (OpenAI, Anthropic, Azure, etc.) has its own adapter that:

1. **Converts LangChain input** to provider-specific format
2. **Enables streaming mode** via provider API parameters
3. **Parses SSE (Server-Sent Events)** from the response
4. **Transforms provider chunks** into `AIMessageChunk` objects

**Example: OpenAI Adapter**

```python
class ChatOpenAI(BaseChatModel):
    def _generate(self, messages, stream=True, **kwargs):
        # Call OpenAI API with stream=True
        response = self.client.chat.completions.create(
            model=self.model_name,
            messages=messages,
            stream=True,
            **kwargs
        )

        # Parse SSE and yield chunks
        for chunk in response:
            if chunk.choices[0].delta.content:
                yield AIMessageChunk(
                    content=chunk.choices[0].delta.content
                )
```

---

## Message Chunks and Accumulation

### AIMessageChunk Structure

Unlike `invoke()` which returns a complete `AIMessage`, `stream()` yields `AIMessageChunk` objects:

```python
class AIMessageChunk(AIMessage):
    content: str                    # Partial text content
    response_metadata: dict         # Provider metadata
    id: Optional[str]               # Message identifier

    def __add__(self, other):
        """Chunks can be added together"""
        return AIMessageChunk(
            content=self.content + other.content,
            response_metadata=self.response_metadata
        )
```

### Chunk Accumulation Pattern

LangChain chunks are designed to be accumulated via simple addition:

```python
full = None
for chunk in model.stream("What color is the sky?"):
    full = chunk if full is None else full + chunk
    print(full.content)  # Accumulated content

# Output progression:
# The
# The sky
# The sky is
# The sky is typically
# The sky is typically blue
```

**Key Insight**: Each `chunk.content` contains only the **new** text (delta), but adding chunks together accumulates the full response.

---

## Auto-Streaming

LangChain can automatically enable streaming even when you use `invoke()`:

### How It Works

When `invoke()` is called in a streaming context (e.g., within a LangGraph agent being streamed), LangChain detects the streaming mode and internally switches to streaming:

```python
def invoke(self, input, config=None):
    # Check if we're in a streaming context
    if self._is_streaming_context(config):
        # Use internal streaming but return complete result
        return self._stream_and_accumulate(input, config)
    else:
        # Normal non-streaming path
        return self._generate_non_streaming(input, config)
```

### Benefits

- **Backward Compatibility**: Existing code using `invoke()` automatically benefits from streaming
- **Real-Time Callbacks**: `on_llm_new_token` callbacks fire even with `invoke()`
- **Transparent**: User code doesn't need to change

**Example: LangGraph Auto-Streaming**

```python
def call_model(state):
    # Uses invoke() but streams internally
    response = model.invoke(state["messages"])
    return {"messages": [response]}

# When streaming the graph, tokens are emitted in real-time
for chunk in graph.stream({"messages": ["Hello"]}):
    print(chunk)
```

---

## Callback System Integration

LangChain's callback system provides deep visibility into streaming operations:

### Streaming Callback Events

```python
from langchain_core.callbacks import BaseCallbackHandler

class TokenCounter(BaseCallbackHandler):
    def on_llm_start(self, prompts, **kwargs):
        print("🚀 Starting LLM generation")

    def on_llm_new_token(self, token, **kwargs):
        print(f"📝 Token: {repr(token)}")

    def on_llm_end(self, response, **kwargs):
        print(f"✅ Finished. Total tokens: {len(response.content)}")

# Use with streaming
model.stream("Hello", config={"callbacks": [TokenCounter()]})
```

### Event Flow

```
User calls llm.stream(input)
    │
    ├─> on_llm_start event
    │
    ├─> Loop:
    │   ├─> Receive chunk from provider API
    │   ├─> on_llm_new_token event (for each chunk)
    │   └─> Yield AIMessageChunk to user
    │
    └─> on_llm_end event
```

### Callback Propagation

Callbacks automatically propagate through chains:

```python
chain = prompt | llm | parser

# Single callback handler for entire chain
for chunk in chain.stream(input, config={"callbacks": [handler]}):
    pass
```

All components in the chain receive the same callbacks, enabling end-to-end tracing.

---

## LCEL Chain Streaming

LangChain Expression Language (LCEL) enables seamless streaming through chains:

### Basic Chain Streaming

```python
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

prompt = ChatPromptTemplate.from_template("Tell me a joke about {topic}")
chain = prompt | llm | StrOutputParser()

# Streaming works through the entire chain
for chunk in chain.stream({"topic": "programming"}):
    print(chunk, end="", flush=True)
```

### How Chain Streaming Works

```
Input → Prompt → LLM → Parser → Output
         │        │       │
         │        │       └─> Streams parsed string chunks
         │        └─> Streams AIMessageChunk objects
         └─> Not streaming (instant transformation)
```

**Internal Implementation:**

```python
class RunnableSequence:
    def stream(self, input, config=None):
        # Stream through first runnable
        for chunk1 in self.steps[0].stream(input, config):
            # Pass chunk to next runnable
            for chunk2 in self.steps[1].stream(chunk1, config):
                # Continue through chain
                for chunk3 in self.steps[2].stream(chunk2, config):
                    yield chunk3
```

### Parallel Streaming

When using `RunnableParallel` or `RunnableMap`, each branch streams independently:

```python
from langchain_core.runnables import RunnableParallel

chain = RunnableParallel(
    joke=llm.stream("Tell me a joke"),
    poem=llm.stream("Write a haiku")
)

# Both streams emit independently
for chunk in chain.stream({}):
    print(chunk)
    # Output: {"joke": "Why..."}
    #         {"poem": "Code..."}
```

---

## Custom Streaming with Transform

For advanced use cases, you can create custom streaming components using `RunnableGenerator`:

### RunnableGenerator

Wraps a generator function to create a streaming Runnable:

```python
from langchain_core.runnables import RunnableGenerator

def custom_stream(input):
    """Custom streaming logic"""
    for item in input.split():
        yield f"Processed: {item}"

custom_runnable = RunnableGenerator(custom_stream)

for chunk in custom_runnable.stream("hello world"):
    print(chunk)
# Output:
# Processed: hello
# Processed: world
```

### Transform Method

Implement `transform()` for more control over streaming:

```python
from langchain_core.runnables import Runnable

class CustomProcessor(Runnable):
    def transform(self, input_stream, config=None):
        """Process a stream of inputs"""
        for item in input_stream:
            # Transform each item
            yield item.upper()

# Use in chain
chain = llm | CustomProcessor()
for chunk in chain.stream("hello"):
    print(chunk)  # Yields uppercase chunks
```

### Use Cases

1. **Output Parsers**: Parse streaming JSON or structured data
2. **Token Filtering**: Filter or modify tokens in real-time
3. **Aggregation**: Aggregate chunks into custom formats
4. **Side Effects**: Trigger actions based on streaming content

---

## Best Practices

### 1. Always Consume Streams Completely

```python
# Good: Consume entire stream
for chunk in llm.stream(input):
    print(chunk, end="")

# Bad: Abandon stream mid-iteration
for chunk in llm.stream(input):
    if "error" in chunk:
        break  # Leaves connection open
```

### 2. Use Context Managers for Resources

```python
# Ensures cleanup even with errors
try:
    for chunk in llm.stream(input):
        print(chunk, end="")
except Exception as e:
    print(f"Error: {e}")
```

### 3. Accumulate Chunks Properly

```python
# Correct accumulation
full_message = None
for chunk in llm.stream(input):
    full_message = chunk if full_message is None else full_message + chunk

# Now full_message is a complete AIMessage
print(full_message.content)
```

### 4. Handle Empty Chunks

```python
for chunk in llm.stream(input):
    # Some chunks may have empty content (metadata-only)
    if chunk.content:
        print(chunk.content, end="")
```

### 5. Use Appropriate Stream Mode

In LangGraph, choose the right stream mode:

```python
# "updates": State updates after each node
for chunk in graph.stream(input, stream_mode="updates"):
    print(chunk)

# "messages": Individual message chunks (real-time)
for chunk in graph.stream(input, stream_mode="messages"):
    print(chunk)

# "custom": Custom data from get_stream_writer()
for chunk in graph.stream(input, stream_mode="custom"):
    print(chunk)
```

---

## Comparison: Stream vs Invoke

| Feature | `invoke()` | `stream()` |
|---------|-----------|------------|
| **Return Type** | Single `AIMessage` | Iterator of `AIMessageChunk` |
| **Latency** | High (wait for full response) | Low (first chunk fast) |
| **User Experience** | Delayed | Real-time |
| **Memory** | Low (single message) | Low (incremental) |
| **Cancellability** | No | Yes (can break mid-stream) |
| **Auto-Streaming** | ✅ Yes (in streaming context) | ✅ Always |
| **Callbacks** | ✅ Yes | ✅ Yes (per token) |

---

## Summary

LangChain's streaming implementation is built on the `Runnable` interface, providing:

1. **Unified API**: All components support `stream()` consistently
2. **Automatic Propagation**: Streaming flows through entire chains
3. **Chunk Accumulation**: Messages aggregate via simple addition
4. **Callback Integration**: Rich event system for monitoring
5. **Auto-Streaming**: `invoke()` can stream transparently
6. **Custom Streaming**: `RunnableGenerator` for custom logic

**Internal Flow:**

```
llm.stream(input)
    │
    ├─> Convert input to provider format
    │
    ├─> Call provider API with stream=True
    │
    ├─> Parse SSE response
    │
    ├─> For each chunk:
    │   ├─> Create AIMessageChunk
    │   ├─> Trigger on_llm_new_token callback
    │   └─> Yield to user
    │
    └─> Trigger on_llm_end callback
```

This architecture makes streaming in LangChain both powerful and intuitive, enabling real-time AI applications with minimal code complexity.

---

## References

- [LangChain Streaming Overview](https://docs.langchain.com/oss/python/langchain/streaming/overview)
- [LangChain Models Documentation](https://docs.langchain.com/oss/python/langchain/models)
- [Runnable Interface Reference](https://reference.langchain.com/v0.3/python/core/runnables/langchain_core.runnables.base.Runnable.html)
- [LCEL Documentation](https://docs.langchain.com/oss/python/langchain/expression_language)